//
//  ViewController.swift
//  War
//
//  Created by Macbook Air on 9/4/17.
//  Copyright © 2017 Macbook Air. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var rightimageview: UIImageView!
    @IBOutlet weak var leftimageview: UIImageView!
    @IBOutlet weak var rightscorelabel: UILabel!
    var rightScore = 0
    @IBOutlet weak var leftscorelabel: UILabel!
    var leftScore=0
    
    let cardName = ["card2", "card3", "card4", "card5", "card6", "card7", "card8", "card9", "card10", "jack", "queen", "king","ace"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func dealTapped(_ sender: Any) {
        
        //randomize left card
        let leftNumber = Int(arc4random_uniform(13))
        leftimageview.image = UIImage(named: cardName[leftNumber])
        
       //randomize right card
       
        let rightNumber = Int(arc4random_uniform(13))
        rightimageview.image = UIImage(named: cardName[rightNumber] )
        
       //Update score
        
        if leftNumber > rightNumber { //Player wins
            leftScore += 1
            leftscorelabel.text = String(leftScore)
        }
        
        else if leftNumber == rightNumber { // it's a tie!
            
        }
        
        else { //CPU Wins
            rightScore += 1
            rightscorelabel.text = String(rightScore)
            
        }
    
    }

}

